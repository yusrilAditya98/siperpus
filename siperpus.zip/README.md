# siperpus
Sistem informasi perpustakaan FH UB adalah sebuah layanan perpustakan untuk memudahkan civitas fakultas hukum dalam menggunakan layanan perpustakan seperti meminjam buku, melihat artikel online, hingga laporan kegiatan perpustakan.
